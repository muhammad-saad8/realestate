<?php wp_footer(); ?>
</body>
</html> <!-- end of site. what a ride! -->
