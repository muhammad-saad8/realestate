<?php
/**
 * Element class
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_G5Element_Bullet_One_Page_Scroll_Navigation extends G5Element_ShortCode_Base {
}
