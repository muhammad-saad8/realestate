<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<div class="g5core__not-found w-100 g5ere__not-found alert alert-info" role="alert">
	<?php esc_html_e('No agent were found matching your selection.','g5-ere')?>
</div>