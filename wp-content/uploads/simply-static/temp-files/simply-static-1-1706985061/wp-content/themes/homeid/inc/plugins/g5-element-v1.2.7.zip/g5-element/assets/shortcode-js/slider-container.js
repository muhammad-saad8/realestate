(function ($) {
	"use strict";
	var G5Element_Slider_Container = {
		init: function () {
		},
	};
	$(document).ready(function () {
        G5Element_Slider_Container.init();
	});
})(jQuery);