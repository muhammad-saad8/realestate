<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
/**
 * @var $property_bedrooms
 */
?>
<span class="g5ere__property-bedrooms"><?php echo sprintf(esc_html__('%s Br','g5-ere'),$property_bedrooms)?></span>
