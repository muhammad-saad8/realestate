<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<button type="button" class="btn btn-block btn-send-message" data-toggle="modal" data-target="#g5ere__modal_messenger">
	<?php esc_html_e('Send Message', 'g5-ere') ?>
</button>
