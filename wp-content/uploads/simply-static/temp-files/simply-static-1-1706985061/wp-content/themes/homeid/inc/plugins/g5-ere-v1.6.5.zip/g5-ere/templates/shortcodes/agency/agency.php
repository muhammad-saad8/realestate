<?php
/**
 * The template for displaying button.php
 *
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
class WPBakeryShortCode_G5Element_Agency extends G5Element_ShortCode_Listing_Base {
}
