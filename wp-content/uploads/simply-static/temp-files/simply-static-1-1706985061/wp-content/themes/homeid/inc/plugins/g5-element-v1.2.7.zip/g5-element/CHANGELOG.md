Changelog
=========
#### 1.2.7 - November 09, 2023
* Fix function get_template

#### 1.2.6 - February 10, 2023
* Fix icon box color when not using icon svg animated

#### 1.2.5 - December 14, 2022
* Fix icon box when using icon svg animated

#### 1.2.4 - October 18, 2022
* Update testimonial

#### 1.2.3 - June 17, 2022
* Update lazy load

#### 1.2.2 - May 20, 2022
* Update fontawsome to 5.15.4

#### 1.2.1 - April 27, 2022
* Fix enqueue assets mega menu

#### 1.2.0 - October 29, 2021
* Add shortcode Bullet One Page Scroll Navigation

#### 1.1.9 - October 06, 2021
* Update Icon box for svg icon
* Update Hover Image Effect for image box

#### 1.1.8 - July 16, 2021
* Update Hover Image Effect

#### 1.1.7 - June 22, 2021
* Add shortcode map box 

#### 1.1.6 - May 10, 2021
* Add shortcode image marker 

#### 1.1.5 - April 05, 2021
* Fix error when add new vc_grid_item post type

#### 1.1.4 - February 19, 2021
* Fix update plugin WPBakery Page Builder

#### 1.1.3 - February 18, 2021
* Fix translate content block and mega menu with wpml

#### 1.1.2 - January 23, 2021
* Update image size shortcode image box

#### 1.1.1 - January 13, 2021
* Fix warning width and height shortcode banner

#### 1.1.0 - December 29, 2020
* Fix style line ending both DOS and UNIX

#### 1.0.9 - October 16, 2020
* Update layout metro of shortcode gallery
* Add fillter g5element_map_style_config

#### 1.0.8 - July 28, 2020
* Update param image hover in shortcode image box

#### 1.0.7 - June 30, 2020
* Fix custom color hover

#### 1.0.6 - April 03, 2020
* Fix edit page with WPBakery Page Builder in backend

#### 1.0.5 - March 28, 2020
* Fix edit page with WPBakery Page Builder in frontend
* Fix error enqueue shortcode assets with php 7.4 

#### 1.0.0 - February 25, 2017
* Inital Version